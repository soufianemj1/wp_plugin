<?php


/**
 * Plugin name: Contact form
 * Description: Simple non-bloated WordPress Contact Form
 * 
 */
function app_output_buffer()
{
    ob_start();
} 
add_action('init', 'app_output_buffer');

function tablecreation() {

   global $wpdb;

         $charset_collate = $wpdb->get_charset_collate();
         $tablename = 'contact';
         $sql = "CREATE TABLE $wpdb->base_prefix$tablename (
              id INT AUTO_INCREMENT,
             name varchar(255) DEFAULT null,
             email varchar(255) DEFAULT null,
             message varchar(255) DEFAULT null,
             PRIMARY key(id)
             ) $charset_collate;";
     
         require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
     
         maybe_create_table($wpdb->base_prefix . $tablename, $sql);
}
//creation table avec l'activation
register_activation_hook(__FILE__,'tablecreation');

//add page dashboard
add_action('admin_menu','admin_menu');

//drope table uninstall
register_uninstall_hook(__FILE__,'droptable');



 
function pagecontact() 
{
     include 'pluginAdmin.php';
}


function admin_menu() {
   add_menu_page("Contact Menu","Contact Menu","manage_options","Contact-menu","pagecontact","dashicons-format-status",2 );
}


function droptable() 
{
   global $wpdb;
    $table_name=$wpdb->prefix."contact";

    $wpdb -> query("DROP TABLE IF exists $table_name");

   


}





function contactForm()
{
   include "pluginform.php";
    return ob_get_clean();
}

add_shortcode('contact', 'contactForm');

 add_action( 'wp_print_styles', 'add_my_plugin_stylesheet' );

 function add_my_plugin_stylesheet() {
    wp_register_style('mypluginstylesheet', '/wp-content/plugins/postgrid/style.css');

    wp_register_style('prefix_bootstrap', '//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css');
    wp_enqueue_style('mypluginstylesheet');
    wp_enqueue_style('prefix_bootstrap');
 }

 add_action('wp_print_scripts','add_my_plugin_js');

 function add_my_plugin_js() {
    wp_register_script('prefix_bootstrap', '//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js');
    wp_enqueue_script('prefix_bootstrap');
 }





 ?>