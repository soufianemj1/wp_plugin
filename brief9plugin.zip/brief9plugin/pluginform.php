<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>contact</title>
</head>
<body>

<form action="" method="POST">

<div class="input-group mb-3">
  <span class="input-group-text" id="basic-addon1">Name</span>
  <input name="nom" type="text" class="form-control" placeholder="name" aria-describedby="basic-addon1">
</div>
<div class="input-group mb-3">
  <span class="input-group-text" id="basic-addon1">E-mail</span>
  <input name="email" type="email" class="form-control" placeholder="email" aria-describedby="basic-addon1">
</div>
<div class="input-group">
  <span class="input-group-text">your </br> message</span>
  <textarea name="message" class="form-control" aria-label="With textarea"></textarea>
</div>

<div class="col-md-12 text-center pt-3">
<button type="submit" class="btn btn-primary">send</button>
</div>

</form>


<?php
 if (isset($_POST['nom'])){
    global $wpdb;
    $name=$_POST['nom'];
    $email=$_POST['email'];
    $message=$_POST['message'];

    $table_name=$wpdb->prefix .'contact';
    $wpdb->insert(
       $table_name, 
      [
         'name'=>$name,
         'email'=>$email,
         'message'=>$message
         ] 
         );
         wp_redirect($_SERVER["REQUEST_URI"], 301);
        exit();
 }

 




?>
    
</body>
</html>